document.getElementById("start").addEventListener("click", () => {
  const file = document.getElementById("csvFile").files[0];

  Papa.parse(file, {
    header: true,
    complete: (results) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { data: results.data },
          (response) => {
            if (response.notFound.length > 0) {
              downloadCSV(response.notFound);
            }
            document.getElementById("status").innerText = "Process Complete";
          },
        );
      });
    },
  });
});

function downloadCSV(data) {
  const csv = Papa.unparse(data);
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "items_not_found.csv";
  a.click();
}
